from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'ralph_lauren_secret_key_123'

# Пример базы данных пользователей
users = {
    'admin': generate_password_hash('admin123')
}

# Каталог товаров Polo Ralph Lauren
products = [
    {
        'id': 1,
        'name': 'Polo Custom Fit Mesh Polo',
        'price': 125,
        'description': 'Классическая поло с фирменным логотипом пошита из дышащей сетчатой ткани piqué.',
        'image': '/static/images/polo1.jpg',
        'category': 'polos',
        'colors': ['Белый', 'Черный', 'Синий'],
        'sizes': ['S', 'M', 'L', 'XL']
    },
    {
        'id': 2,
        'name': 'Custom Fit Oxford Shirt',
        'price': 145,
        'description': 'Рубашка из оксфордской ткани с кнопками на воротнике и фирменным логотипом пошива.',
        'image': '/static/images/shirt1.jpg',
        'category': 'shirts',
        'colors': ['Голубой', 'Белый', 'Розовый'],
        'sizes': ['S', 'M', 'L']
    },
    {
        'id': 3,
        'name': 'Bear Sweater',
        'price': 295,
        'description': 'Свитер с фирменным медвежонком Polo Ralph Lauren из мягкой шерсти.',
        'image': '/static/images/sweater1.jpg',
        'category': 'sweaters',
        'colors': ['Красный', 'Синий', 'Бежевый'],
        'sizes': ['S', 'M', 'L', 'XL']
    },
    {
        'id': 4,
        'name': 'Pony Emblem T-Shirt',
        'price': 65,
        'description': 'Футболка с фирменной эмблемой Polo Pony из мягкого хлопка.',
        'image': '/static/images/tshirt1.jpg',
        'category': 'tshirts',
        'colors': ['Белый', 'Черный', 'Серый'],
        'sizes': ['S', 'M', 'L', 'XL']
    }
]


@app.route('/')
def home():
    featured = [p for p in products if p['id'] in [1, 3]]  # Избранные товары
    return render_template('index.html', featured=featured, products=products)


@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = next((p for p in products if p['id'] == product_id), None)
    if not product:
        flash('Товар не найден', 'error')
        return redirect(url_for('home'))
    return render_template('product.html', product=product)


@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'cart' not in session:
        session['cart'] = []

    product_id = int(request.form.get('product_id'))
    quantity = int(request.form.get('quantity', 1))
    color = request.form.get('color')
    size = request.form.get('size')

    product = next((p for p in products if p['id'] == product_id), None)
    if product:
        item = next((item for item in session['cart'] if
                     item['id'] == product_id and item['color'] == color and item['size'] == size), None)
        if item:
            item['quantity'] += quantity
        else:
            session['cart'].append({
                'id': product_id,
                'name': product['name'],
                'price': product['price'],
                'quantity': quantity,
                'color': color,
                'size': size,
                'image': product['image']
            })
        session.modified = True
        flash('Товар добавлен в корзину', 'success')
    else:
        flash('Товар не найден', 'error')

    return redirect(request.referrer or url_for('home'))


@app.route('/cart')
def view_cart():
    cart_items = session.get('cart', [])
    total = sum(item['price'] * item['quantity'] for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)


@app.route('/remove_from_cart/<int:index>')
def remove_from_cart(index):
    if 'cart' in session and 0 <= index < len(session['cart']):
        session['cart'].pop(index)
        session.modified = True
        flash('Товар удален из корзины', 'info')
    return redirect(url_for('view_cart'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if username in users and check_password_hash(users[username], password):
            session['user'] = username
            flash('Вы успешно вошли в систему', 'success')
            return redirect(url_for('home'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('home'))


@app.route('/category/<category>')
def view_category(category):
    category_products = [p for p in products if p['category'] == category]
    if not category_products:
        flash('Категория не найдена', 'error')
        return redirect(url_for('home'))

    category_name = {
        'polos': 'Рубашки Polo',
        'shirts': 'Рубашки',
        'sweaters': 'Свитеры',
        'tshirts': 'Футболки'
    }.get(category, category)

    return render_template('category.html', products=category_products, category_name=category_name)


if __name__ == '__main__':
    app.run(debug=True)